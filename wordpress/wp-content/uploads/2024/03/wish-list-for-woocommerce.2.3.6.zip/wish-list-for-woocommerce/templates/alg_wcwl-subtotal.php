<div style="margin:25px 0" class="alg-wc-wl-subtotal"><strong><?php _e( 'Subtotal', 'wish-list-for-woocommerce' ) ?></strong>:
	<span class="alg-wc-wl-subtotal-value"><?php echo wp_kses_post( $subtotal_value_html ); ?></span>
</div>

